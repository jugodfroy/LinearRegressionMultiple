# RegressionLinearMultiple

Data Analysis Cranfield Project

Please, if some figures are not well displayed in the .ipynb file, you can check the .pdf files.
